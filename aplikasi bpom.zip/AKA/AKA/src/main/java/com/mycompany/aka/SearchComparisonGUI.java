/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aka;

/**
 *
 * @author mac
 */
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

public class SearchComparisonGUI extends JFrame {
    private JTextField searchField;
    private JTextArea resultArea;
    private ArrayList<Produk> produkList; // Database lokal

    public SearchComparisonGUI() {
        setTitle("Pencarian dan Pengurutan Kode BPOM");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Data / Database
        produkList = Produk.initProduk();

        // Panel input di bagian atas
        JPanel inputPanel = new JPanel(new FlowLayout());

        JLabel label = new JLabel("Masukkan Kode BPOM:");
        inputPanel.add(label);

        searchField = new JTextField(20);
        inputPanel.add(searchField);

        JButton searchButton = new JButton("Cari");
        searchButton.addActionListener(e -> performSearch());
        inputPanel.add(searchButton);

        add(inputPanel, BorderLayout.NORTH);

        // Area hasil di bagian tengah
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
    }

    private void performSearch() {
        String target = searchField.getText();
        if (target.isEmpty()) {
            resultArea.setText("Harap masukkan kode BPOM.");
            return;
        }

        // Buat dataset untuk grafik
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Simulasi untuk ukuran data yang bervariasi
        for (int size = 5; size <= produkList.size(); size += 5) {
            ArrayList<Produk> testList = new ArrayList<>(produkList.subList(0, size));

            // Ukur waktu untuk iteratif
            long startIterative = System.nanoTime();
            Search.sequentialSearchIterative(testList, target);
            long endIterative = System.nanoTime();

            // Ukur waktu untuk rekursif
            long startRecursive = System.nanoTime();
            Search.sequentialSearchRecursive(testList, target, 0);
            long endRecursive = System.nanoTime();

            // Tambahkan data ke grafik
            dataset.addValue((endIterative - startIterative), "Iteratif", String.valueOf(size));
            dataset.addValue((endRecursive - startRecursive), "Rekursif", String.valueOf(size));
        }

        // Buat grafik berdasarkan dataset
        JFreeChart chart = ChartFactory.createLineChart(
            "Waktu Pencarian",
            "Ukuran Data",
            "Waktu (ns)",
            dataset
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 400));

        // Hapus panel grafik lama (jika ada)
        for (Component comp : getContentPane().getComponents()) {
            if (comp instanceof ChartPanel) {
                remove(comp);
                break;
            }
        }
        add(chartPanel, BorderLayout.SOUTH);

        // Perbarui tampilannya
        revalidate();

        // Tampilkan hasil pencarian
        long startIterative = System.nanoTime();
        Produk iterativeResult = Search.sequentialSearchIterative(produkList, target);
        long endIterative = System.nanoTime();

        long startRecursive = System.nanoTime();
        Produk recursiveResult = Search.sequentialSearchRecursive(produkList, target, 0);
        long endRecursive = System.nanoTime();

        StringBuilder output = new StringBuilder();
        output.append("Hasil Pencarian Iteratif:\n");
        if (iterativeResult != null) {
            output.append(iterativeResult).append("\n");
        } else {
            output.append("Data tidak ditemukan.\n");
        }
        output.append("Waktu (iteratif): ").append((endIterative - startIterative) / 1e6).append(" ms\n");

        output.append("\nHasil Pencarian Rekursif:\n");
        if (recursiveResult != null) {
            output.append(recursiveResult).append("\n");
        } else {
            output.append("Data tidak ditemukan.\n");
        }
        output.append("Waktu (rekursif): ").append((endRecursive - startRecursive) / 1e6).append(" ms\n");

        resultArea.setText(output.toString());
        searchField.setText("");
    }
}





